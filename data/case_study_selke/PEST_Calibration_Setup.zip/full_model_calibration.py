"""
Worfklow to do a full model calibration using Pest
"""

import os
import sys
import shutil
import pandas as pd
from pathlib import Path
def generate_instruction_file(simulation_results_path,output_dir):
    """
    Write the Instuction File

    Returns
    -------
    None.

    """
    print('generate pest instruction file...',end='')
    model_results=pd.read_csv(simulation_results_path,delimiter=' ')
    with open(os.path.join(output_dir,'output_pst_csv.ins'), 'w') as instruction_file:
        instruction_file.write('pif @'+'\n')
        instruction_file.write('@simulation@'+'\n')
        #we go line by line
        for obs_id in range(0,len(model_results)):
            instruction_file.write('l1 w !'+'obs_'+str(obs_id)+'!'+'\n')
        
        print('...done')
# Get the current directory of the script
current_dir = os.path.dirname(os.path.realpath(__file__))
os.chdir(current_dir)

# Append the parent directory to the system path
parent_dir = os.path.abspath(os.path.join(current_dir, os.pardir))
sys.path.append(os.path.join(parent_dir,'_1_StratMerge'))
sys.path.append(r'C:\Nixdorf.E\Arbeit\Lausitz\Grobmodell_Lausitz\Gromola')
# Now you can import the module from the parent directory
from stratmerge.stratmerge import StratMerge
from gromola import gromola


#%% We start the stratmerge workflow by generating full 2D averaged property field (5 different hydrogeological layers)
model = StratMerge(StratMerge.read_config('calibration_setup_stratmerge.yml'))
model.paths['output_dir'] = current_dir / Path('Output') /Path('selke_spr') / Path(model.identifier)
model.generate_stratigraphic_ensemble(basic_layer='pt',
                                    vertical_averaging = True,
                                    all_layers_only=True,
                                    stats_to_use = ['mean'])

#copy the generated map to the Selke input data
stratmerge_identifier = model.identifier
#ensemble_identifier = [file for file in os.listdir(os.path.join(model.output_dir,stratmerge_identifier)) 

spr_output_dir = model.paths['output_dir'] / Path('ascii_files')

property_files=['single_layer_kf_value_x_mean.asc','single_layer_porosity_x_mean.asc','single_layer_thick.asc']
#copy the files
gwm_property_dir = os.path.join(current_dir,'data','selke_primola','Hydrogeologie','property_maps')

for property_file in property_files:
    

    shutil.copy2(os.path.join(spr_output_dir,property_file), gwm_property_dir) # complete target filename given
    

#now we call the gromola workflow to generate the output data
gw_model = gromola.model('calibration_setup_gromola.yml',output_dir=os.path.join(current_dir,'output','selke_gromola'))
gw_model.simulate()

# copy the results from stratmerge and 
for property_file in property_files:
    

    shutil.copy2(os.path.join(spr_output_dir,property_file), gw_model.output_dir) # complete target filename given

#copy the config file of stratmerge there
shutil.copy2('calibration_setup_stratmerge.yml', gw_model.output_dir)

#we copy the calibration_result to the current dir
#we load the flux data
head_results = pd.read_csv(os.path.join(gw_model.output_dir,'_5_simulation','output_pst_head_metrics.csv'),delimiter=' ')
flux_result = pd.read_csv(os.path.join(gw_model.output_dir,'_5_simulation','output_fluxes.csv'),delimiter=' ')
print('GW Flow to mine is assumed to be  - 300l/s, which means -0.3m³/s')
flux_result=flux_result.rename(columns={'feature_id':'well_id'})
flux_result.loc[0,'observation'] = -0.3
flux_result.loc[0,'well_id'] = 99
ogs_metrics = pd.concat([head_results,flux_result],axis=0).reset_index(drop=True)
ogs_metrics['well_id'] = ogs_metrics['well_id'].astype(int)
ogs_metrics = ogs_metrics.drop(columns=['observation','well_id'])
ogs_metrics.to_csv(os.path.join(current_dir,'ogs_metrics.csv'),sep=' ')

obs_path = os.path.join (gw_model.output_dir,'_5_simulation','ogs_metrics.csv')
ogs_metrics.to_csv(os.path.join(obs_path),sep=' ')
generate_instruction_file(obs_path,current_dir)

