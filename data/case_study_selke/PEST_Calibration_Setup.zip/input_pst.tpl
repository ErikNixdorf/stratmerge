ptf !
info:
    model_name: selke
    contact: Erik Nixdorf
data_io:
    data_dir: data\examples\ex1
    output_dir: output
    nodata_value: -9999
    save_subsets:
        save_layer_ascii: true
        save_layer_nc: true
        save_model_statistics: true
stratigraphic_layers:
    mi:
        layer_id: 0
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf1       !
            porosity:
                is_isotropic: true
                mean: 0.17
    ntgwl1:
        layer_id: 1
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf2       !
            porosity:
                is_isotropic: true
                mean: 0.25
    mtgwl3:
        layer_id: 2
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf3       !
            porosity:
                is_isotropic: true
                mean: 0.28
    egm:
        layer_id: 3
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf4       !
            porosity:
                is_isotropic: true
                mean: 0.11
    htgwl5:
        layer_id: 4
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf5       !
            porosity:
                is_isotropic: true
                mean: 0.26
    q:
        layer_id: 5
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf6       !
            porosity:
                is_isotropic: true
                mean: 0.19
    t:
        layer_id : 6
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf7       !
            porosity:
                is_isotropic: true
                mean: 0.17
    pt:
        layer_id: 7
        properties:
            kf_value:
                is_isotropic: true
                mean: !       kf8       !
            porosity:
                is_isotropic: true
                mean: 0.10
merge_stratigraphiclayers:
    activate: true    
    merge_rules:
        gwl_up:
            - ntgwl1
            - mtgwl3
        unstructured_Sediments:
            - q
            - t
    mask_bedding_plane_orientation:
        activate: false
        max_slope_deviation: 10 # in degree
generate_planar_model:
    activate: false
    base_layer: pt # has to cover entire spatial_domain
    base_layer_thickness: 10 # if non, default will be used
build_3d_mesh:
    activate: false
    path_to_extruder: C:\\"Program Files"\\Data_Explorer\\bin\\createLayeredMeshFromRasters.exe
    path_to_planar_mesh: C:\Nixdorf.E\Arbeit\Publicationen\Paper_in_Progress\SPR_Geohydromodelling\Data\StratMerge\example_data\selke\planar_mesh\nachterstedt_triangles_reordered.vtu
    path_to_dem: C:\Nixdorf.E\Arbeit\Publicationen\Paper_in_Progress\SPR_Geohydromodelling\Data\StratMerge\example_data\selke\dem\dem.asc
    remove_soil_layer: true
    minimum_layer_depth: 1

    